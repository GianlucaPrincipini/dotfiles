-- ~/.config/nvim/lua/custom/mappings.lua

---@type MappingsTable
local M = {}

M.general = {
  i = {
    -- Esci dall'insert mode premendo jj
    ["jj"] = { "<ESC>", "Exit insert mode with jj" },
  },
}

return M

