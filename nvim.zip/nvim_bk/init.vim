" Personal settings
syntax on
set number
set relativenumber
set ruler
set cursorline
set modeline
set vb
set incsearch 
set hlsearch
set sw=2 
set expandtab 
set smarttab
set encoding=utf-8
set textwidth=0 
set wrapmargin=0
set nowrap
set nolist " Unset by default
set listchars=tab:→\ ,space:·,nbsp:␣,trail:•,eol:¶,precedes:«,extends:»
set tabstop=4
set shiftwidth=4
let mapleader = ","
let g:vimspector_base_dir="/Users/gianluca/.config/vimspector/"
set t_Co=256


so ~/.config/nvim/coc-mappings.vim
so ~/.config/nvim/nerdtree-mappings.vim
so ~/.config/nvim/plugins.vim
so ~/.config/nvim/airline-settings.vim

" Others
imap jj <ESC>
nmap . :

" Search in files
nnoremap <silent> <Leader>f :Rg<CR>

" Buffer navigation
nnoremap <silent> <Space>b :bp<CR>
nnoremap <silent> <Space>n :bn<CR>
nnoremap <silent> <Space>w :bd<CR>

" Colors
colorscheme gruvbox

" Autoclose brackets and string
inoremap " ""<left>
inoremap ' ''<left>
inoremap ( ()<left>
inoremap [ []<left>
inoremap { {}<left>
inoremap {<CR> {<CR>}<ESC>O
inoremap {;<CR> {<CR>};<ESC>O

" Autosave 
autocmd BufNewFile,BufRead *.java :autocmd TextChanged,TextChangedI <buffer> silent write
autocmd BufNewFile,BufRead *.sbt :autocmd TextChanged,TextChangedI <buffer> silent write
autocmd BufNewFile,BufRead *.scala :autocmd TextChanged,TextChangedI <buffer> silent write

" Debug 
" "nnoremap <Leader>b <Plug>VimspectorToggleBreakpoint
" "nnoremap <Leader>dc <Plug>VimspectorContinue
" "nnoremap <Leader>ds <Plug>VimspectorStop
" "nnoremap <Leader>dr <Plug>VimspectorRestart
" "nnoremap <Leader>ds <Plug>VimspectorStepOver
" "nnoremap <Leader>di <Plug>VimspectorStepInto

nnoremap <silent>== :Format<CR> 

so ~/.config/nvim/config.lua
