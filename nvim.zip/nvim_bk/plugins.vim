call plug#begin()
""""" GRAPHICAL PLUGINS """""
" Themes
Plug 'flazz/vim-colorschemes'
Plug 'joshdick/onedark.vim'
Plug 'jacoborus/tender.vim'

" Status bar
""Plug 'vim-airline/vim-airline'
""Plug 'vim-airline/vim-airline-themes'

" Lua
""Plug 'nvim-lua/plenary.nvim'

" Markdown preview
Plug 'iamcco/markdown-preview.nvim', { 'do': 'cd app && yarn install'  }

" Nerdtree
Plug 'scrooloose/nerdtree'

"""""" IDE FEATURES """"""
" coc features
Plug 'neoclide/coc.nvim', {'branch': 'release'}

" Debug / run
""Plug 'puremourning/vimspector'

" vimtest
Plug 'janko/vim-test'

"fuzzy finder
Plug 'junegunn/fzf', { 'do': { -> fzf#install() } }
Plug 'junegunn/fzf.vim'

" Git plugin
Plug 'tpope/vim-fugitive'

" Surround
Plug 'tpope/vim-surround'

call plug#end()

